#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 10:57:07 2024

@author: antiXLinux
"""

def subtract(a, b):
    return a - b

# permite ejecutar una parte específica del código solo cuando el archivo main.py 
# sea ejecutado directamente (no importado en otro archivo)
# if __name__ == "__main__":
#     print(subtract(133, -5))